import React from 'react'

type HeroTitleProps = {
    title:string
}

export const HeroTitle:React.FC<HeroTitleProps> = ({ title }) => {
  return (
    <h2>{title}</h2>
  )
}
