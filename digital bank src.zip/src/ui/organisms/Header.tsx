import React from 'react'
import logo from '../../assets/logo-dark.svg'

import { LogoImage } from '../atoms/LogoImage'
import { HeaderNavList } from '../molecules/HeaderNavList'
import { Button } from '../atoms/Button'

export const Header: React.FC = () => {

    const navList = ['Home', 'About', 'Contact', 'Blog', 'Careers'];

    return (
        <header className='d-flex justify-content-around align-items-center p-3'>
            <LogoImage logo={logo} logoName='Digital bank' />
            <HeaderNavList navList={navList} />
            <Button buttonText='Request Invite'/>
        </header>
    )
}
