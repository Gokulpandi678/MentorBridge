import React from 'react'
import { Header } from '../ui/organisms/Header'
import { Hero } from '../ui/organisms/Hero'

export const Home = () => {
  return (
    <div>
        <Header />
        <Hero />
    </div>
  )
}
