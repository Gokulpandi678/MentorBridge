import React from 'react'

type SectionTitleProps = {
    title: string   
}

export const SectionTitle:React.FC<SectionTitleProps> = ({ title }) => {
  return (
    <div>{title}</div>
  )
}
