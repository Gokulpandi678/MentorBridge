import React from 'react'

type HighLightCardProps = {
    avatar: string,
    avatarName: string,
    title: string,  
    Description: string
}

export const HighLightCard:React.FC<HighLightCardProps> = ( {avatar, avatarName, title, Description} ) => {
  return (
    <div>
        <img src={avatar} alt={avatarName} />
        <h4>{title}</h4>
        
    </div>
  )
}
