import React from 'react'
import { NavText } from '../atoms/NavText'

type HeaderNavListProps = {
    navList:string[]
}

export const HeaderNavList:React.FC<HeaderNavListProps> = ({ navList }) => {
  return (
    <ul className='list-unstyled d-flex gap-5'>
        {
            navList.map((item) => <NavText navText={item}/>)
        }
    </ul>
  )
}
