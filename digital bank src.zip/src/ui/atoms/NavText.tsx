import React from 'react'

type NavTextProps = {
    navText:string
}

export const NavText:React.FC<NavTextProps> = ({ navText }) => {
  return (
    <li className='hover-text-blue'>{navText}</li>
  )
}
